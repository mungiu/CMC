/*
 * 02.10.2016 Minor edit
 * 29.10.2009 New package structure
 * 26.10.2006 Original version
 */
 
package dk.via.jpe.intlang;


public class Type
{
	public boolean rvalueOnly;
	
	
	public Type( boolean rvalueOnly )
	{
		this.rvalueOnly = rvalueOnly;
	}
}