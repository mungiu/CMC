/*
 * 27.09.2016 Minor edit
 * 29.10.2009 New package structure
 * 29.09.2006
 */
 
package dk.via.jpe.intlang.ast;


public abstract class Statement
	extends AST
{
}