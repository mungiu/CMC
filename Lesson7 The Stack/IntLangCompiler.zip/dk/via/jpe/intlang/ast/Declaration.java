/*
 * 27.09.2016 Minor edit
 * 29.10.2009 New package structure
 * 29.09.2006 Original version
 */
 
package dk.via.jpe.intlang.ast;


public abstract class Declaration
	extends AST
{
}