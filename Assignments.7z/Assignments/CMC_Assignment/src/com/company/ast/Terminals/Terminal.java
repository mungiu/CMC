package com.company.ast.Terminals;

import com.company.ast.AST;

public abstract class Terminal extends AST {
    public String spelling;
    public char aChar;
}
