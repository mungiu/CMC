package com.company.ast.Commands;

import com.company.ast.Command;

public abstract class Expression extends Command {
}
