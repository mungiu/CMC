package com.company.ast;

import com.company.ast.AST;

public abstract class Command extends AST {
}
