package com.company.VisitorsPattern;

public class Type {
    public boolean rvalueOnly;

    public Type(boolean rvalueOnly) {
        this.rvalueOnly = rvalueOnly;
    }
}
